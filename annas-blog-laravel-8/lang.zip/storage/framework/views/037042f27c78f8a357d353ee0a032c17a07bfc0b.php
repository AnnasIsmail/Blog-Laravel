


<?php $__env->startSection('container'); ?>

<h2 class="mb-3"><?php echo e($title); ?></h2>

<div class="container-posts">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-4">
        <img src="https://source.unsplash.com/1200x800?<?php echo e($category->name); ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($category->name); ?></h5>
            <a href="/posts?category=<?php echo e($category->slug); ?>">See All Posts</a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annas\OneDrive\Desktop\koding\Blog-Laravel\annas-blog-laravel-8\resources\views/categories.blade.php ENDPATH**/ ?>