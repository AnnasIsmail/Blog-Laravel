


<?php $__env->startSection('container'); ?>

<form action="/authors">
    <div class="input-group mb-3 mt-3">
        <input type="text" name="search" class="form-control" placeholder="Search Author..." aria-label="Recipient's username" aria-describedby="button-addon2" value="<?php echo e(request('search')); ?>">
        <button class="btn btn-dark" type="submit" id="button-addon2">Search</button>
    </div>
</form>

<div class="container-posts">
    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="card mb-4">
        <?php if($author->image): ?>
            <img src="<?php echo e(asset('storage/' . $author->image)); ?>" class="card-img-top max-h-32" alt="...">
        <?php else: ?>
            <img src="https://source.unsplash.com/1200x800?people" class="card-img-top max-h-32" alt="...">
        <?php endif; ?>
        <div class="card-body">
            <h5 class="card-title"><?php echo e($author->name); ?></h5>
            <p class="card-text"><?php echo e($author->email); ?></p>
            <a href="/posts?author=<?php echo e($author->username); ?>">See All Posts</a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="d-flex justify-content-center mt-3">
    <?php echo e($authors->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annas\OneDrive\Desktop\koding\Blog-Laravel\annas-blog-laravel-8\resources\views/authors.blade.php ENDPATH**/ ?>