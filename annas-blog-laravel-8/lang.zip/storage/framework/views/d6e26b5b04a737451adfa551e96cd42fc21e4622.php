

<?php $__env->startSection('container'); ?>

    <div class="card my-4 ">
        <?php if($post->image): ?>
            <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="card-img-top max-h-32" alt="...">
        <?php else: ?>
            <img src="https://source.unsplash.com/1200x800?<?php echo e($post->category->name); ?>" class="card-img-top max-h-32" alt="...">
        <?php endif; ?>
        <div class="card-body">
        <h2 class="card-title"><?php echo e($post->title); ?></h2>
        <h5>
            Category <a class="text-decoration-none" href="/posts?category=<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a>
        </h5>
        <h5>
            Author <a class="text-decoration-none" href="/posts?author=<?php echo e($post->user->username); ?>"><?php echo e($post->user->name); ?></a>
        </h5>
        <p class="card-text"></p>
        <div class="d-flex gap-4 border-dark mt-2">
            <a href="/dashboard/posts" class="text-decoration-none"> <h6><span data-feather="arrow-left" class="align-text-bottom link"></span> Back My Posts</h6></a>
            <a href="/dashboard/posts/<?php echo e($post->slug); ?>/edit" class="text-decoration-none"> <h6><span data-feather="edit" class="align-text-bottom link"></span> Edit Post</h6></a>
            <form action="/dashboard/posts/<?php echo e($post->slug); ?>" method="post" class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button class="border-0 bg-transparent px-0" onclick="return confirm('Are you sure?')">
                    <a href="#" class="text-decoration-none"> <h6><span data-feather="trash-2" class="align-text-bottom link"></span> Remove Post</h6></a>
                </button>
            </form>
        </div>

        <p class="card-text"><?php echo $post->body; ?></p>
        <p class="card-text"><small class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?></small></p>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annas\OneDrive\Desktop\koding\Blog-Laravel\annas-blog-laravel-8\resources\views/dashboard/post/show.blade.php ENDPATH**/ ?>