


<?php $__env->startSection('container'); ?>

<?php if(request('category') && request('author')): ?>
    <h1 class="text-center mt-3">Author <?php echo e($posts[0]->user->name); ?> and Category <?php echo e($posts[0]->category->name); ?></h1>
<?php elseif(request('category')): ?>
    <h1 class="text-center mt-3">Category <?php echo e($posts[0]->category->name); ?></h1>
<?php elseif(request('author')): ?>
    <h1 class="text-center mt-3">Author <?php echo e($posts[0]->user->name); ?></h1>
<?php else: ?>
    <h1 class="text-center mt-3">All Posts</h1>
<?php endif; ?>
    
<form action="/posts">
    <div class="input-group mb-3 mt-3">
        <?php if(request('category')): ?>
            <input name="category" type="hidden" class="form-control" placeholder="Search Post..." aria-label="Recipient's username" aria-describedby="button-addon2" value="<?php echo e(request('category')); ?>">
        <?php endif; ?>    
        <?php if(request('author')): ?>
            <input name="author" type="hidden" class="form-control" placeholder="Search Post..." aria-label="Recipient's username" aria-describedby="button-addon2" value="<?php echo e(request('author')); ?>">
        <?php endif; ?>  
        <input name="search" type="text" class="form-control" placeholder="Search Post..." aria-label="Recipient's username" aria-describedby="button-addon2" value="<?php echo e(request('search')); ?>">
        <button class="btn btn-dark" type="submit" id="button-addon2">Search</button>
    </div>
</form>

<?php if(count($posts) > 0): ?>

    <div class="container-posts mb-4">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card h-100">
                <?php if($post->image): ?>
                    <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="card-img-top max-h-32" alt="...">
                <?php else: ?>
                    <img src="https://source.unsplash.com/1200x800?<?php echo e($post->category->name); ?>" class="card-img-top max-h-32" alt="...">
                <?php endif; ?>
                <div class="card-body">
                <h4 class="card-title">
                    <a class="text-dark" href="/posts/<?php echo e($post->slug); ?>">
                        <?php echo e($post->title); ?>

                    </a>
                </h4>
                <p class="card-text"><?php echo e($post->excerpt); ?></p>
                <h6>
                    Category
                    <?php if(request('category')): ?>
                        <?php echo e($post->category->name); ?>

                    <?php elseif(request('author')): ?>
                        <a class="text-decoration-none" href="/posts?author=<?php echo e(request('author')); ?>&category=<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a>
                    <?php else: ?>
                        <a class="text-decoration-none" href="/posts?category=<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a>
                    <?php endif; ?>  
                        
                </h6>
                <h6>
                    Author
                    <?php if(request('author')): ?>
                    <?php echo e($post->user->name); ?>

                    <?php elseif(request('category')): ?>
                         <a class="text-decoration-none" href="/posts?category=<?php echo e(request('category')); ?>&author=<?php echo e($post->user->username); ?>"><?php echo e($post->user->name); ?></a>
                    <?php else: ?>
                        <a class="text-decoration-none" href="/posts?author=<?php echo e($post->user->username); ?>"><?php echo e($post->user->name); ?></a>
                    <?php endif; ?>  
                        
                </h6>
                </div>
                <div class="card-footer">
                <small class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?></small>
                </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <?php else: ?>
    <p class="text-center fs-4">No Post Found.</p>
    <?php endif; ?>

    <div class="d-flex justify-content-center mt-3">
        <?php echo e($posts->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annas\OneDrive\Desktop\koding\Blog-Laravel\annas-blog-laravel-8\resources\views/posts.blade.php ENDPATH**/ ?>