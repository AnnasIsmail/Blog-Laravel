

<?php $__env->startSection('container'); ?>
    <h1><?php echo e($name); ?></h1>
    <h3><?php echo e($email); ?></h3>
    <img src="<?php echo e($image); ?>" alt="">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annas\OneDrive\Desktop\koding\Blog-Laravel\annas-blog-laravel-8\resources\views/about.blade.php ENDPATH**/ ?>