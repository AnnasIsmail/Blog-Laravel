

<?php $__env->startSection('container'); ?>
    <h1>Hello, world!</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annas\OneDrive\Desktop\koding\Blog-Laravel\annas-blog-laravel-8\resources\views/home.blade.php ENDPATH**/ ?>