

<?php $__env->startSection('container'); ?>

    <div class="card mb-4">
        <?php if($post->image): ?>
            <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="card-img-top max-h-32" alt="...">
        <?php else: ?>
            <img src="https://source.unsplash.com/1200x800?<?php echo e($post->category->name); ?>" class="card-img-top max-h-32" alt="...">
        <?php endif; ?>
        <div class="card-body">
        <h2 class="card-title"><?php echo e($post->title); ?></h2>
        <h5>
            Category <a class="text-decoration-none" href="/posts?category=<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a>
        </h5>
        <h5>
            Author <a class="text-decoration-none" href="/posts?author=<?php echo e($post->user->username); ?>"><?php echo e($post->user->name); ?></a>
        </h5>
        <p class="card-text"><?php echo $post->body; ?></p>
        <p class="card-text"><small class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?></small></p>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annas\OneDrive\Desktop\koding\Blog-Laravel\annas-blog-laravel-8\resources\views/post.blade.php ENDPATH**/ ?>