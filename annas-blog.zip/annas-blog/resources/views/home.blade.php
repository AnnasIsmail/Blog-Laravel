@extends('layout.layout')

@section('container')
    <h1>Hello, world!</h1>
@endsection
